import streamlit as st


st.set_page_config(
    page_title= 'Home',
    page_icon = "Hi"
)

st.write("# Welcome to Steamlit !!")

st.sidebar.success("Sel ect a demo above.")